#include"at89x52.h" 
#include"intrins.h" 
//************************************ 
#define  uint  unsigned int 
#define  uchar unsigned char 
#define  Nack_counter  10 
//************** �˿ڶ���************** 
//LCD �����߽ӿ� 
uchar flag1; 
sbit  RS=P0^7; 
sbit  RW=P0^6; 
sbit  LCDE=P0^5; 
//mlx90614 �˿ڶ��� 
sbit  SCL=P1^6;// ʱ���� 
sbit  SDA=P1^7;// ������ 
//************ ���ݶ���**************** 
bdata uchar flag;//��λѰַ���� 
sbit bit_out=flag^7; 
sbit bit_in=flag^0; 
uchar DataH,DataL,Pecreg; 
//************ ��������***************************************** 
void   start_bit();                 //MLX90614 ����ʼλ�ӳ��� 
void   stop_bit();                 //MLX90614������λ�ӳ��� 
uchar  rx_byte(void);              //MLX90614 �����ֽ��ӳ��� 
void   send_bit(void);             //MLX90614����λ�ӳ��� 
void   tx_byte(uchar dat_byte);     //MLX90614 �����ֽ��ӳ��� 
void   receive_bit(void);           //MLX90614����λ�ӳ��� 
void   delay(uint N);              //��ʱ���� 
uint   memread(void);             // ���¶����� 
void   init1602(void);        //LCD ��ʼ���ӳ��� 
void   chk_busy_flg(void);         //LCD �ж�æ�ӳ��� 
void   dis_cmd_wrt(uchar cmd);     //LCD д�����ӳ��� 
void   dis_dat_wrt(uchar dat);       //LCD д�����ӳ��� 
void   display(uint Tem);           // ��ʾ�ӳ��� 
//*************������******************************************* 
void main() 
{ 
 uint Tem; 
 //�������� 
 SCL=1;SDA=1;_nop_(); 
 _nop_();_nop_();_nop_(); 
 SCL=0; 
 delay(1000); 
 SCL=1; 
 init1602(); 
 while(1) 
 { 
   Tem=memread(); 
   display(Tem); 
   delay(20); 
 } 
} 
//*********����ת������ʾ********* 
void display(uint Tem) 
{ 
 uint T,a,b; 
 T=Tem*2; 
  dis_cmd_wrt(0x01);//���� 
 if(T>=27315) 
 { 
   T=T-27315; 
   a=T/100; 
   b=T-a*100; 
//--------------------------- 
   if(a>=100) 
   { 
    dis_dat_wrt(0x30+a/100); 
    a=a%100; 
    dis_dat_wrt(0x30+a/10); 
    a=a%10; 
    dis_dat_wrt(0x30+a); 
   } 
   else if(a>=10) 
   { 
    dis_dat_wrt(0x30+a/10); 
    a=a%10; 
    dis_dat_wrt(0x30+a); 
   } 
   else 
   { 
    dis_dat_wrt(0x30+a); 
   } 
   dis_dat_wrt(0x2e);// ��ʾ�� 
   //--------------------------- 
  if(b>=10) 
  { 
    dis_dat_wrt(0x30+b/10); 
//    b=b%10; 
//    dis_dat_wrt(0x30+b); 
  } 
  else 
  { 
    dis_dat_wrt(0x30); 
//    dis_dat_wrt(0x30+b); 
  } 
 } 
//==========
 else 
 { 
  T=27315-T; 
  a=T/100; 
    b=T-a*100; 
  dis_dat_wrt(0x2d); 
//-------------------------- 
  if(a>=10) 
  { 
    dis_dat_wrt(0x30+a/10); 
    a=a%10; 
    dis_dat_wrt(0x30+a); 
  } 
  else 
  { 
    dis_dat_wrt(0x30+a); 
  } 
  dis_dat_wrt(0x2e);//��ʾ�� 
//-------------------------- 
  if(b>=10) 
  { 
    dis_dat_wrt(0x30+b/10); 
    b=b%10; 
    dis_dat_wrt(0x30+b); 
  } 
  else 
  { 
    dis_dat_wrt(0x30); 
    dis_dat_wrt(0x30+b); 
  } 
 } 
} 

//************************************ 
void   start_bit(void) 
{ 
   SDA=1; 
   _nop_();_nop_();_nop_();_nop_();_nop_(); 
   SCL=1; 
   _nop_();_nop_();_nop_();_nop_();_nop_(); 
   SDA=0; 
   _nop_();_nop_();_nop_();_nop_();_nop_(); 
   SCL=0; 
   _nop_();_nop_();_nop_();_nop_();_nop_(); 
 
} 
//------------------------------ 
void   stop_bit(void) 
{ 

   SCL=0; 
   _nop_();_nop_();_nop_();_nop_();_nop_(); 
   SDA=0; 
   _nop_();_nop_();_nop_();_nop_();_nop_(); 
   SCL=1; 
   _nop_();_nop_();_nop_();_nop_();_nop_(); 
   SDA=1; 
} 
//--------- ����һ���ֽ�--------- 
void  tx_byte(uchar dat_byte) 
{ 
   char i,n,dat; 
   n=Nack_counter; 
TX_again: 
   dat=dat_byte; 
   for(i=0;i<8;i++) 
   { 
     if(dat&0x80) 
      bit_out=1; 
     else 
      bit_out=0; 
     send_bit(); 
     dat=dat<<1; 
   } 
   
      receive_bit(); 
   if(bit_in==1) 
   { 
    stop_bit(); 
    if(n!=0) 
    {n--;goto Repeat;} 
    else 
     goto exit; 
   } 
   else 
    goto exit; 
Repeat: 
    start_bit(); 
    goto TX_again; 
exit: ; 
} 
//-----------����һ��λ--------- 
void  send_bit(void) 
{ 
  if(bit_out==0) 
  
       SDA=0; 
  else 
     SDA=1; 
  _nop_(); 
  SCL=1; 
  _nop_();_nop_();_nop_();_nop_(); 
  _nop_();_nop_();_nop_();_nop_(); 
  SCL=0; 
  _nop_();_nop_();_nop_();_nop_(); 
  _nop_();_nop_();_nop_();_nop_(); 
} 
//---------- ����һ���ֽ�-------- 
uchar rx_byte(void) 
{ 
  uchar i,dat; 
  dat=0; 
  for(i=0;i<8;i++) 
  { 
    dat=dat<<1; 
    receive_bit(); 
    if(bit_in==1) 
     dat=dat+1; 
  } 
  send_bit(); 
  return dat; 
} 

//---------- ����һ��λ---------- 
void receive_bit(void) 
{ 
  SDA=1;bit_in=1; 
  SCL=1; 
  _nop_();_nop_();_nop_();_nop_(); 
  _nop_();_nop_();_nop_();_nop_(); 
  bit_in=SDA; 
  _nop_(); 
  SCL=0; 
  _nop_();_nop_();_nop_();_nop_(); 
  _nop_();_nop_();_nop_();_nop_(); 
} 
//------------ ��ʱ-------------- 
void   delay(uint N) 
{ 
  uint i; 
  for(i=0;i<N;i++) 
  
     _nop_(); 
} 
//------------------------------ 
uint memread(void) 
{ 
  start_bit(); 
  tx_byte(0xB4);  //Send SlaveAddress ==============================
  //tx_byte(0x00); 
  tx_byte(0x07);  //Send Command 
  //------------ 
  start_bit(); 
  tx_byte(0x01); 
  bit_out=0; 
  DataL=rx_byte(); 
  bit_out=0; 
  DataH=rx_byte(); 
  bit_out=1; 
  Pecreg=rx_byte(); 
  stop_bit(); 
  return(DataH*256+DataL); 
} 
//******************LCD ��ʾ�Ӻ���*********************** 
void init1602(void)        // ��ʼ��LCD 
{ 
   dis_cmd_wrt(0x01); 
   dis_cmd_wrt(0x0c); 
   dis_cmd_wrt(0x06); 
   dis_cmd_wrt(0x38); 
   
   } 
 
void chk_busy_flg(void) //LCD æ��־�ж� 
{ 
   flag1=0x80; 
  while(flag1&0x80) 
 { 
   P2=0xff; 
   RS=0; 
   RW=1; 
   LCDE=1; 
   flag1=P2; 
   LCDE=0; 
 } 
} 
 
void dis_cmd_wrt(uchar cmd)    // д�����Ӻ��� 
{ 
   chk_busy_flg(); 
   P2=cmd; 
   RS=0; 
   RW=0; 
   LCDE=1; 
   LCDE=0; 
} 
 
void dis_dat_wrt(uchar dat) // д�����Ӻ��� 
{ 
  chk_busy_flg(); 
  if(flag1==16) 
  { 
   P2=0XC0; 
   RS=0; 
   RW=0; 
   LCDE=1; 
   LCDE=0; 
  } 
   P2=dat; 
   RS=1; 
   RW=0; 
   LCDE=1; 
   LCDE=0; 
} 
 
